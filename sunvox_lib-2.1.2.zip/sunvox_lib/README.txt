SunVox Library
https://warmplace.ru/soft/sunvox/sunvox_lib.php

sunvox_lib - SunVox Library itself; please read sunvox_lib/docs/readme.txt
lib_* - auxiliary libraries that will be required if you rebuild the SunVox Library from sources.
