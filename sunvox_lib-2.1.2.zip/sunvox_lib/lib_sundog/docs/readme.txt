SunDog engine is a set of libraries for creating cross-platform applications.
Examples of such applications: SunVox, Pixilang.

lib_sundog - engine base: memory, files, graphics and sound;
../lib_dsp, ../lib_gif, etc. - optional libraries; some depend on SunDog and some don't;

[ Versions ]

SunDog 1 - initial version (started in 2004)

SunDog 2 - v1 modification (started in 2023), in the same source tree (some components have been changed or replaced)
(not yet publicly available)
