#pragma once

int metamodule_load( const char* name, sfs_file f, int mod_num, psynth_net* pnet );
