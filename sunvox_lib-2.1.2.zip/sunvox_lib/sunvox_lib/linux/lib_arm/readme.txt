Versions for old Linux devices (ARMEL; ARMv7-A (Cortex-A8); glibc 2.5 (2006)):
  sunvox_armel

Versions for modern Linux devices (ARMHF; ARMv6; glibc 2.28 (2018)):
  sunvox
